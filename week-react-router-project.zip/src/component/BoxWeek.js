import React, {Component, Fragment} from 'react';

class BoxWeek extends Component{

    render() {
        return(
            <Fragment>
                <h1 className="text-center">주간 박스오피스</h1>
            </Fragment>
        )
    }

}

export default BoxWeek;