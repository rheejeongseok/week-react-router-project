import React, {Component, Fragment} from 'react';

class BoxMonth extends Component{

    render() {
        return(
            <Fragment>
                <h1 className="text-center">월간 박스오피스</h1>
            </Fragment>
        )
    }

}

export default BoxMonth;