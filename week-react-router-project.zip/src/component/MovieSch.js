import React, {Component, Fragment} from 'react';

class MovieSch extends Component{

    render() {
        return(
            <Fragment>
                <h1 className="text-center">개봉 예정 영화</h1>
            </Fragment>
        )
    }

}

export default MovieSch;