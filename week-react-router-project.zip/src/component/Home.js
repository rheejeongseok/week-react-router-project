import React, {Component, Fragment} from 'react';

class Home extends Component{

    render() {
        return(
            <Fragment>
                <h1 className="text-center">홈</h1>
            </Fragment>
        )
    }

}

export default Home;