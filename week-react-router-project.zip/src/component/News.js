import React, {Component, Fragment} from 'react';

class News extends Component{

    render() {
        return(
            <Fragment>
                <h1 className="text-center">영화 뉴스</h1>
            </Fragment>
        )
    }

}

export default News;