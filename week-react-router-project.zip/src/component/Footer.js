import React, {Component, Fragment} from 'react';

class Footer extends Component{

    render() {
        return(
            <Fragment>
                <div>
                    test
                </div>
            </Fragment>
        )
    }

}

export default Footer;